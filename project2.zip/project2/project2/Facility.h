#ifndef FACILITY_H
#define FACILITY_H
/////////////////////////////////////////////////////////////////////////////
// Facility.h - Provide additional functionality to XmlDocument object     //
// ver 1.0                                                                 //
// ----------------------------------------------------------------------- //
// copyright ?Siyuan(Jeremy) Ye, 2015                                      //
// All rights granted provided that this notice is retained                //
// ----------------------------------------------------------------------- //
// Application: Spring Assignment Projects, 2015                           //
// Author:      Siyuan(Jeremy) Ye, Syracuse University                     //
/////////////////////////////////////////////////////////////////////////////
/*
* Package Operations:
* -------------------
* Facility receives a pointer to XmlDocument object to get DocElement. Then provide
* the functionalities that the project asks.
* - display the whole tree.
* - find the unique id attribute.
* - find all elements have specific id and value.
* - find all elements are match with tag.
* - add or remove child, found by tag or id.
* - output the whole tree to a file.
*
* User Interface:
* showResult();
* findUniqueAttri("id");
* findEle("tag");
* addChildByTag("tag", sPtr);
* removeChildByTag("tag", sPtr)
* addChildById("id", sPtr);
* removeChildById("id", sPtr);
* toFile("filename");
* showCommandLine(argc, argv);
* readFile("filename");
*
* Required Files:
* ---------------
* Facility.h, Facility.cpp, XmlDocument.h, XmlDocument.cpp,
* XmlElement.h, XmlElement.cpp
*
* Build Process:
* --------------
* From the Visual Studio Developer's Command Prompt:
* devenv project2.sln /rebuild debug
*
* Maintenance History:
* --------------------
* - Ver 1.0 : 18 Mar 2015
*   first release
*/
#include "XmlDocument.h"

class Facility{
public:
	Facility(XmlProcessing::XmlDocument* doc) : pDoc(doc){}
	void showResult();
	sPtr findUniqueAttri(const std::string& name);
	void findAttri(std::vector<sPtr>&, const sPtr &, const std::string&, const std::string& value = "");
	std::vector<sPtr> findEle(const std::string& tag);
	bool addChildByTag(const std::string& tag, const sPtr& child);
	bool removeChildByTag(const std::string& tag, const sPtr& child);
	bool addChildById(const std::string& id, const sPtr& child);
	bool removeChildById(const std::string& id, const sPtr& child);
	void toFile(const std::string& filename);
	static void checkInput(int& input);
	static void showCommandLine(int argc, char** argv);
	static void readFile(const std::string& filename);
private:
	XmlProcessing::XmlDocument *pDoc;
};

#endif