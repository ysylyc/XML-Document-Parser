/////////////////////////////////////////////////////////////////////////////
// Parser.h - Receive string or filename from exec, then parsering it.     //
// ver 1.0                                                                 //
// ----------------------------------------------------------------------- //
// copyright ?Siyuan(Jeremy) Ye, 2015                                      //
// All rights granted provided that this notice is retained                //
// ----------------------------------------------------------------------- //
// Application: Spring Assignment Projects, 2015                           //
// Author:      Siyuan(Jeremy) Ye, Syracuse University                     //
/////////////////////////////////////////////////////////////////////////////
#include <sstream>
#include <utility>
#include "Parser.h"
#include "XmlElement.h"

using sPtr = std::shared_ptr < XmlProcessing::AbstractXmlElement > ;
// read source and put every line into a vector called needToAnalysis
void Parser::setXmlSrc(const std::string& src, bool isFile){
	if (needToAnalysis.size() != 0){
		needToAnalysis.clear();
	}
	Toker toker(src, isFile);
	toker.setMode(Toker::xml);
	XmlParts parts(&toker);
	while (parts.get()){
		needToAnalysis.push_back(parts.show().c_str());
	}
}
// find a substr from a string, return true if found
bool Parser::findstr(const std::string& src, const std::string& needTofind){
	std::string::size_type n = src.find(needTofind);
	return (n == std::string::npos) ? false : true;
}

// split a string depends on a specific delim
void Parser::split(const std::string &src, char delim, std::vector<std::string> &result){
	result.clear();
	std::stringstream ss(src);
	std::string item;
	while (std::getline(ss, item, delim)) {
		result.push_back(item);
	}
}
// extract attributes from one line
void Parser::extractAttrib(std::vector<std::string>& name, std::vector<std::string>& value, const std::string src){
	std::vector<std::string> result;
	std::string delim;
	split(src, ' ', result);
	for (size_t i = 0; i < result.size(); i++){
		if (findstr(result[i], "=")){
			name.push_back(result[i - 1]);
			delim = result[i + 1];
		}
	}
	split(src, delim[0], result);
	for (size_t i = 0; i < result.size(); i++){
		if ((i % 2) != 0){
			value.push_back(result[i]);
		}
	}
}
// check the identifier from one line
Parser::type_ Parser::checkIdentifier(const std::string& src){
	if (findstr(src, "< ? ")){
		return Parser::ProcInstrElement;
	}
	else if (findstr(src, "< ! ")){
		return Parser::CommentElement;
	}
	else if (findstr(src, "< ")){
		return Parser::TaggedElement;
	}
	else return Parser::TextElement;
}
// make a new DeclarElement from souce
sPtr Parser::processDE(const std::string& line){
	std::vector<std::string> name;
	std::vector<std::string> value;
	extractAttrib(name, value, line);
	auto ptr = XmlProcessing::makeXmlDeclarElement();
	for (size_t i = 0; i < name.size(); i++){
		ptr->addAttrib(name[i], value[i]);
	}
	return ptr;
}
// make a new CommentElement from souce
sPtr Parser::processCE(const std::string& line){
	std::vector<std::string> result;
	std::string text;
	size_t pos1 = line.find("!");
	size_t pos2 = line.rfind(">");
	text = line.substr(pos1 + 2, pos2 - pos1 - 3);
	auto ptr = XmlProcessing::makeCommentElement(text);
	return ptr;
}
// make a new ProcInstrElement from souce
sPtr Parser::processPIE(const std::string& line){
	std::vector<std::string> result;
	std::vector<std::string> name;
	std::vector<std::string> value;
	std::string text;
	int pos1, pos2;
	split(line, ' ', result);
	for (size_t i = 0; i < result.size(); i++){
		if (result[i] == "?"){
			pos1 = i;
		}
		if (result[i] == "="){
			pos2 = i;
			break;
		}
	}
	for (pos1; pos2 - pos1 > 2; pos1++){
		text = text + result[pos1 + 1];
	}
	auto ptr = XmlProcessing::makeProcInstrElement(text);
	extractAttrib(name, value, line);
	for (size_t i = 0; i < name.size(); i++){
		ptr->addAttrib(name[i], value[i]);
	}
	return ptr;
}
// make a new TextElement from souce
sPtr Parser::processTextE(const std::string& line){
	auto ptr = XmlProcessing::makeTextElement(line);
	return ptr;
}
// make a new TaggedElement from souce
sPtr Parser::processTag(const std::string& line){
	std::vector<std::string> result;
	std::vector<std::string> name;
	std::vector<std::string> value;
	std::string tag;
	split(line, ' ', result);
	int pos1 = 2, pos2;
	for (size_t i = 0; i < result.size(); i++){
		if (result[i] == "="){
			pos2 = i;
			for (pos1; pos2 - pos1 > 2; pos1++){
				tag = tag + result[pos1 + 1];
			}
			break;
		}
		else if (result[i] == "/" || result[i] == ">"){
			pos2 = i;
			for (pos1; pos2 - pos1 > 1; pos1++){
				tag = tag + result[pos1 + 1];
			}
			break;
		}
	}
	auto ptr = XmlProcessing::makeTaggedElement(tag);
	extractAttrib(name, value, line);
	for (size_t i = 0; i < name.size(); i++){
		ptr->addAttrib(name[i], value[i]);
	}
	return ptr;
}
// send one line one time to make new element and build the tree
void Parser::processGroup(const sPtr& root, const std::vector<std::string>& tagSrc){
	std::vector<std::string> name;
	std::vector<std::string> value;
	sPtr prevprev, prev, curr;
	prevprev = prev = curr = root;
	// create DeclarElement first
	root->addChild(processDE(tagSrc[0]));

	for (size_t i = 1; i < tagSrc.size(); i++){
		switch (checkIdentifier(tagSrc[i]))
		{
		case 1:{
			root->addChild(processPIE(tagSrc[i]));
			break;
		}
		case 2:{
			prev->addChild(processCE(tagSrc[i]));
			break;
		}
		case 3:{
			if (findstr(tagSrc[i], "< /")){
				// make the prev pointer back to upper level
				prev = prevprev;
				break;
			}
			curr = processTag(tagSrc[i]);
			prev->addChild(curr);
			if (!findstr(tagSrc[i], "/")){
				// make the prev pointer going deeper
				prevprev = prev;
				prev = curr;
			}
			break;
		}
		case 4:{
			prev->addChild(processTextE(tagSrc[i]));
			break;
		}
		default:
			break;
		}
	}
}
// parsering the vector needToAnalysis
sPtr Parser::parsering(){
	// create DocElement
	auto DocEle = XmlProcessing::makeDocElement();
	// remove the default XmlDeclarElement
	DocEle->removeChild(DocEle->children()[0]);
	processGroup(DocEle, needToAnalysis);
	return DocEle;
}

//----< test stub >----------------------------------------------------------

#ifdef TEST_PARSER
int main(){
	Parser parser;
	parser.setXmlSrc("LectureNote.xml", true);
	auto proot = parser.parsering();
	std::cout << proot->toString();

	std::cout << "\n\n";

}
#endif