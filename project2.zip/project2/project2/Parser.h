#ifndef PARSER_H
#define PARSER_H
/////////////////////////////////////////////////////////////////////////////
// Parser.h - Receive string or filename from exec, then parsering it.     //
// ver 1.0                                                                 //
// ----------------------------------------------------------------------- //
// copyright ?Siyuan(Jeremy) Ye, 2015                                      //
// All rights granted provided that this notice is retained                //
// ----------------------------------------------------------------------- //
// Application: Spring Assignment Projects, 2015                           //
// Author:      Siyuan(Jeremy) Ye, Syracuse University                     //
/////////////////////////////////////////////////////////////////////////////
/*
* Package Operations:
* -------------------
* Parser receives string or filename from exec, then send them to XmlParts and
* get a vector of lines begin with <, end with >. And make new elements to build 
* an internal parser tree representation. Each XML element is represented by 
* a node in the tree. Some elements may have a finite number of attributes, 
* stored in a std::vector in the element node. Also, some elements may have child 
* elements. And all elements have their type value.
* - read string or file and parsering it to lines, store result into a vector.
* - extract attributes from one line.
* - check the identifier from one line.
* - make new element and build the tree from the vector of lines.
* - parsering the vector of lines.
*
* User Interface:
* setXmlSrc("filename or string", bool isFile);
* parsering();
*
* Required Files:
* ---------------
* Parser.h, Parser.cpp, XmlElementParts.h, XmlElementParts.cpp,
* XmlElement.h, XmlElement.cpp
*
* Build Process:
* --------------
* From the Visual Studio Developer's Command Prompt:
* devenv project2.sln /rebuild debug
*
* Maintenance History:
* --------------------
* - Ver 1.0 : 18 Mar 2015
*   first release
*/
#include <string>
#include <vector>
#include <memory>
#include "XmlElement.h"
#include "XmlElementParts.h"

using namespace XmlProcessing;
class Parser{
public:
	using sPtr = std::shared_ptr < XmlProcessing::AbstractXmlElement >;
	enum type_ { DeclarElement, ProcInstrElement, CommentElement, TaggedElement, TextElement };
	Parser() :needToAnalysis(std::vector<std::string>()){}
	void setXmlSrc(const std::string& src, bool isFile);
	sPtr parsering();
private:
	std::vector<std::string> needToAnalysis;
	bool findstr(const std::string& src, const std::string& needTofind);
	void split(const std::string &src, char delim, std::vector<std::string> &result);
	void extractAttrib(std::vector<std::string>& name, std::vector<std::string>& value, const std::string src);
	Parser::type_ checkIdentifier(const std::string& src);
	sPtr processDE(const std::string& line);
	sPtr processPIE(const std::string& line);
	sPtr processCE(const std::string& line);
	sPtr processTag(const std::string& line);
	void processGroup(const sPtr& root, const std::vector<std::string>& tagSrc);
	sPtr processTextE(const std::string& line);
};












#endif