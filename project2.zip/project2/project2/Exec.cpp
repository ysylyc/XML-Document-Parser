/////////////////////////////////////////////////////////////////////////////
// Facility.h - Demonstration for Project #2                               //
// ver 1.0                                                                 //
// ----------------------------------------------------------------------- //
// copyright ?Siyuan(Jeremy) Ye, 2015                                      //
// All rights granted provided that this notice is retained                //
// ----------------------------------------------------------------------- //
// Application: Spring Assignment Projects, 2015                           //
// Author:      Siyuan(Jeremy) Ye, Syracuse University                     //
/////////////////////////////////////////////////////////////////////////////
/*
* Package Operations:
* -------------------
* Exec accepts command arguemnts to build Parser, XmlDocument and Facility object.
* - Parsering a specific string or file, send the result to build XmlDocument.
* - Builds facility depends on XmlDocument.
* - Displays the whole tree reprentation after first build.
* - Finds unique attribute in the XmlDocument containing a specified id.
* - Finds all elements in the XmlDocument containing a specified tag.
* - Supports related operations of add a child element to, and remove a child from, 
* any element in the tree that can hold child references, found by id or tag.
* - Supports to write and read Xml file from internal tree.
*
* User Interface:
* showResult();
* findUniqueAttri("id");
* findEle("tag");
* addChildByTag("tag", sPtr);
* removeChildByTag("tag", sPtr)
* addChildById("id", sPtr);
* removeChildById("id", sPtr);
* toFile("filename");
* showCommandLine(argc, argv);
* readFile("filename");
*
* Required Files:
* ---------------
* Facility.h, Facility.cpp, XmlDocument.h, XmlDocument.cpp,
* XmlElement.h, XmlElement.cpp, Parser.h, Parser.cpp
*
* Build Process:
* --------------
* From the Visual Studio Developer's Command Prompt:
* devenv project2.sln /rebuild debug
*
* Maintenance History:
* --------------------
* - Ver 1.0 : 18 Mar 2015
*   first release
*/
#include <iostream>
#include <algorithm>
#include <fstream>
#include "Parser.h"
#include "XmlDocument.h"
#include "Facility.h"

class Executive
{
public:
	Executive(int argc, char** argv);
	Executive(const Executive& ex) = delete;
	Executive& operator=(const Executive& ex) = delete;
	const std::shared_ptr<Facility>& getFac();
private:
	int argc_;
	char** argv_;
	std::shared_ptr<XmlDocument> pXmlDocument_ = nullptr;
	std::shared_ptr<Facility> pFacility_ = nullptr;
};

Executive::Executive(int argc, char** argv) :argc_(argc), argv_(argv){
	if (argc_ > 2){
		Parser parser;
		if (argv_[1][0] == '0'){
			parser.setXmlSrc(argv_[2], false);
			title("Demonstrate req#10, read an XML string and build the tree representation.", '=');
			Facility::showCommandLine(argc_, argv_);
		}
		else {
			parser.setXmlSrc(argv_[2], true);
			title("Demonstrate req#11, accepts an XML file.", '=');
			Facility::showCommandLine(argc_, argv_);
		}
		pXmlDocument_ = std::shared_ptr<XmlDocument>(new XmlDocument(parser.parsering()));
		pFacility_ = std::shared_ptr<Facility>(new Facility(pXmlDocument_.get()));
		pFacility_->showResult();
	}
	else if (argc_ == 1){
		pXmlDocument_ = std::shared_ptr<XmlDocument>(new XmlDocument());
		pFacility_ = std::shared_ptr<Facility>(new Facility(pXmlDocument_.get()));
		title("Demonstrate one req of 7, add a root element to an empty doc tree.", '=');
		Facility::showCommandLine(argc_, argv_);
		pFacility_->showResult();
	}
	std::cout << "\n\n\n";
}

const std::shared_ptr<Facility> & Executive::getFac(){ return pFacility_; }

using namespace XmlProcessing;

int main(int argc, char* argv[]){
	Executive exec(argc, argv);
	if (argc > 2 && argv[1][0] == '1'){
		title("Demonstrate req#6, find a collection of elements that have a specified tag.\n  We are going to search tag = title1, then print the result.  ", '=');
		for (auto item : exec.getFac()->findEle("title1")) std::cout << item->toString() << std::endl;
		std::cout << "\n\n\n";
		title("Demonstrate req#5, find the unique id attribute.\n  We are going to search id = lol, then print the result.", '=');
		if (exec.getFac()->findUniqueAttri("lol") != nullptr) std::cout << exec.getFac()->findUniqueAttri("lol")->toString();
		else std::cout << "couldn't find the unique lol attribute.";
		std::cout << "\n\n\n";
		title("Demonstrate req#7, we would print the element before and after every add or remove.", '=');
		std::cout << "\n  Print the the element has tag title.";
		for (auto item : exec.getFac()->findEle("title")) std::cout << item->toString() << std::endl;
		std::cout << "\n  Print the the child We're gonna add.";
		sPtr child = makeTaggedElement("title2");
		child->addAttrib("test", "I'm title2");
		std::cout << child->toString() << std::endl;
		exec.getFac()->addChildByTag("title", child);
		std::cout << "\n  Print the the element after adding.";
		for (auto item : exec.getFac()->findEle("title")) std::cout << item->toString() << std::endl;
		std::cout << "\n  Then we're gonna remove the child we just added.";
		exec.getFac()->removeChildByTag("title", child);
		std::cout << "\n  Print the the element after removing.";
		for (auto item : exec.getFac()->findEle("title")) std::cout << item->toString() << std::endl;
		std::cout << "\n\n\n";
		title("Demonstrate req#8 and #9, we would add and remove lol22=\"I'm 22\" to that element.", '=');
		std::cout << "\n  Display the tagged element reference.";
		sPtr reference = exec.getFac()->findEle("reference")[0];
		std::cout << reference->toString();
		std::cout << "\n  Display the attributes of tagged element reference.";
		for (auto item : reference->attribute()) std::cout << "\n" << item.first << "=\"" << item.second << "\"\n";
		std::cout << "\n  We add lol22=\"I'm 22\" to reference.";
		reference->addAttrib("lol22", "I'm 22");
		std::cout << "\n  Display the attributes after adding.";
		for (auto item : reference->attribute()) std::cout << "\n" << item.first << "=\"" << item.second << "\"\n";
		std::cout << "\n  We remove lol22=\"I'm 22\" to reference.";
		reference->removeAttrib("lol22");
		std::cout << "\n  Display the attributes after removing.";
		for (auto item : reference->attribute()) std::cout << "\n" << item.first << "=\"" << item.second << "\"\n";
		std::cout << "\n\n\n";
		title("Demonstrate req#10, we would create a file named test.xml, then write the whole tree to it.", '=');
		exec.getFac()->toFile("test.xml");
		Facility::readFile("test.xml");
	}
	return 0;
}

// LectureNote.xml  