///////////////////////////////////////////////////////////////////
// XmlDocument.cpp - a container of XmlElement nodes             //
// Ver 1.2                                                       //
// Application: Help for CSE687 Pr#2, Spring 2015                //
// Platform:    Dell XPS 2720, Win 8.1 Pro, Visual Studio 2013   //
// Author:      Jim Fawcett, CST 4-187, 443-3948                 //
//              jfawcett@twcny.rr.com                            //
///////////////////////////////////////////////////////////////////

#include <iostream>
#include <cstring>
#include <utility>
#include "XmlDocument.h"
#include "XmlElementParts.h"

using namespace XmlProcessing;

XmlDocument::XmlDocument() : pDocElement_(makeDocElement()), found_() {
	sPtr root = makeTaggedElement("root");
	pDocElement_->addChild(root);
}
// move assignment
XmlDocument& XmlDocument::operator = (XmlDocument&& xd) {
	if (&xd == this) {
		return *this;
	}
	std::swap(found_, xd.found_);
	std::swap(pDocElement_, xd.pDocElement_);
	return *this;
}
// found_[0] contains first element (DFS order) with tag
XmlDocument& XmlDocument::element(const std::string& tag) {
	std::vector<sPtr> result;
	if (found_.size() == 0) {
		found_ = pDocElement_->children();
	}
	for (auto & item : found_) {
		if (item->getType() == "TaggedElement") {
			DFS(item, tag, result, true);
			if (result.size() > 0) {
				break;
			}
		}
	}
	_ASSERT(result.size() == 0 || result.size() == 1);
	found_ = std::move(result);
	return *this;
}
// found_ contains all elements with tag
XmlDocument& XmlDocument::elements(const std::string& tag) {
	std::vector<sPtr> result;
		found_ = pDocElement_->children();
	for (auto & item : found_) {
		if (item->getType() == "TaggedElement") {
			DFS(item, tag, result, false);
		}
	}
	found_ = std::move(result);
	return *this;
}
// Depth first search
void XmlDocument::DFS(sPtr & p, std::string const & tag, std::vector<sPtr> & result, bool getFirst) {
	if (p->value() == tag) {
		result.push_back(p);
		if (getFirst) {
			return;
		}
	}
	auto children = p->children();
	for (auto & item : children) {
		if (item->getType() == "TaggedElement") {
			DFS(item, tag, result, getFirst);
			if (getFirst && result.size() > 0) {
				return;
			}
		}
	}
}
// Depth first search without tag
void XmlDocument::DFS(sPtr & p, std::vector<sPtr> & result, bool recursive){
	auto children = p->children();
	for (auto tmp : children){
		result.push_back(tmp);
		if (recursive == true){
			DFS(tmp, result, recursive);
		}
	}
}
// found_ contains sPtrs to children of prior found_[0] 
XmlDocument& XmlDocument::children(const std::string& tag){
	if (found_.size() == 0){
		found_.push_back(pDocElement_);
		return *this;
	}
	auto children = found_[0]->children();
	if (tag == ""){
		found_ = std::move(children);
	}
	else{
		std::vector<sPtr> result;
		for (auto tmp : children){
			if (tmp->value() == tag){
				result.push_back(tmp);
			}
		}
		found_ = std::move(result);
	}
	return *this;
}
// found_ contains sPtrs to descendents of prior found_[0]
XmlDocument& XmlDocument::descendents(const std::string& tag){
	if (found_.size() == 0){
		found_.push_back(pDocElement_);
		return *this;
	}
	std::vector<sPtr> result;
	if (tag == ""){
		DFS(found_[0], result, true);
	}
	else{
		auto children = found_[0]->children();
		for (auto & item : children) {
			if (item->getType() == "TaggedElement") {
				DFS(item, tag, result, false);
			}
		}
	}
	found_ = std::move(result);
	return *this;
}




//----< test stub >----------------------------------------------------------

#ifdef TEST_XMLDOCUMENT
int main() {
	title("Testing XmlDocument class");

	XmlDocument doc;
	XmlDocument result;
	std::cout << "\n\n";
	title("Testing XmlElement Package", '=');
	std::cout << "\n";

	using sPtr = std::shared_ptr < AbstractXmlElement >;

	sPtr root = makeTaggedElement("root");
	root->addChild(makeTextElement("this is a test"));


	sPtr child = makeTaggedElement("child");
	child->addChild(makeTextElement("this is another test"));
	child->addAttrib("first", "test");
	root->addChild(child);

	doc.children().select()[0]->addChild(root);

	/*auto test = doc.children().select();
	test[0]->removeChild(test[0]->children()[1]);
	test[0]->addChild(root);*/
	for (auto const & tmp : doc.children().select()){
		std::cout << tmp->toString();
	}
	title("Testing`````````````````````", '=');
	result = std::move(doc.element("root"));
	int count = 0;
	for (auto tmp : result.select()){
		std::cout << tmp->toString();
		std::cout << count++;
	}

	std::cout << "\n\n111111111";

	return 0;
}
#endif